package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class SigninPageObjects {

WebDriver driver;
//Storing the web elements by methods
By button_signin = By.cssSelector("#gnav-header-inner > div.wt-flex-shrink-xs-0 > nav > ul > li:nth-child(1) > button");
By TextBox_Emailaddress = By.cssSelector("input#join_neu_email_field");
By TextBox_Password = By.cssSelector("input#join_neu_password_field");
By button_signin1 = By.cssSelector("#join-neu-form > div.wt-grid.wt-grid--block > div > div:nth-child(10) > div > button");
By button_register = By.cssSelector("#join-neu-form > div.wt-grid.wt-grid--block > div > div:nth-child(1) > div > button");
By TextBox_firstname = By.cssSelector("input#join_neu_first_name_field");
By button_register1 = By.cssSelector("#join-neu-form > div.wt-grid.wt-grid--block > div > div:nth-child(9) > div > button");
By button_cwg = By.xpath("//*[@id=\"join-neu-form\"]/div[3]/div[1]/div/button");
By button_uac = By.cssSelector("#yDmH0d");
By Textbox_email = By.cssSelector("#identifierId");
By button_next = By.cssSelector("#identifierNext > div > button");


public SigninPageObjects (WebDriver driver) {
this.driver = driver;
}
public void clickSignInButton() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_signin).isDisplayed(), "\" signin\" button is displayed");
	//Clicking on signin button
driver.findElement (button_signin).click(); 
}
public void setTextEmailaddress(String Text) {
	//Assertion
	Assert.assertTrue(driver.findElement(TextBox_Emailaddress).isDisplayed(), "\" Emailaddress\" Text is displayed");
	//Entering on Emailaddress button
driver.findElement (TextBox_Emailaddress).sendKeys(Text);  
}
public void setTextInPassword(String Text) {
	//Assertion
	Assert.assertTrue(driver.findElement(TextBox_Password).isDisplayed(), "\" Password TextBox\" Text is displayed");
	//Entering on password button
driver.findElement (TextBox_Password).sendKeys(Text); 
}
public void clickSignInButton1() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_signin1).isDisplayed(), "\" signin1\" button is displayed");
	//Clicking on sigin1 button
driver.findElement (button_signin1).click(); 
}
public void clickregister() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_register).isDisplayed(), "\" register\" button is displayed");
	//Clicking on register button
driver.findElement (button_register).click(); 
}
public void setTextInfirstname(String Text) {
	//Assertion
	Assert.assertTrue(driver.findElement(TextBox_firstname).isDisplayed(), "\" firstname TextBox\" Text is displayed");
	//Entering on firstname button
driver.findElement (TextBox_firstname).sendKeys(Text); 
}
public void clickregister1() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_register1).isDisplayed(), "\" register1\" button is displayed");
	//Clicking on register1 button
driver.findElement (button_register1).click(); 
}
public void clickcwg() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_cwg).isDisplayed(), "\" continue with google\" button is displayed");
	//Clicking on continue with google button
driver.findElement (button_cwg).click(); 
}
public void clickuac() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_uac).isDisplayed(), "\" use another account\" button is displayed");
	//Clicking on email button
driver.findElement (button_uac).click();
}
public void setTextInemail(String Text) {
	//Assertion
	Assert.assertTrue(driver.findElement(Textbox_email).isDisplayed(), "\" use another account\" button is displayed");
	//Entering on email button
driver.findElement (Textbox_email).sendKeys(Text); 
}
public void clicknext() {
	//Assertion
	Assert.assertTrue(driver.findElement(button_next).isDisplayed(), "\" next\" button is displayed");
	//Clicking on next button
driver.findElement (button_next).click(); 
}

}

