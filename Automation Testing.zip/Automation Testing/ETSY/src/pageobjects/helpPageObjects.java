package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class helpPageObjects {
	
	WebDriver driver;
	By button_help = By.cssSelector("#footer-extra-links-help > ul > li:nth-child(1) > a");
	By button_purchasing = By.cssSelector("body > main > div.wt-body-max-width.wt-pr-xs-4.wt-pl-xs-4 > div.home_page__categories-shopping > div.wt-grid.wt-body-max-width.wt-mt-xs-8.wt-mb-xs-5.wt-bb-xs > div > div > div:nth-child(1) > a > p.wt-text-gray.wt-text-caption.wt-mb-xs-1");
	
	public helpPageObjects (WebDriver driver) {
		this.driver = driver;
		}
	public void clickhelpButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_help).isDisplayed(), "\" help and contact\" button is displayed");
		//Clicking on help and contact button
	driver.findElement (button_help).click(); 
	}
	public void clickpurchasingButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_purchasing).isDisplayed(), "\" purchasing\" button is displayed");
		//Clicking on purchasing button
	driver.findElement (button_purchasing).click(); 
	}
}
