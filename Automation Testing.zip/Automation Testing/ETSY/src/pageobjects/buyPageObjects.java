package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class buyPageObjects {
	
	WebDriver driver;
	By button_jewellery = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[2]/a");
	By button_shopthisitem = By.xpath("//*[@id=\"content\"]/div/div[1]/div/div[3]/div[4]/div/div/div/div[2]/a");
	By button_addtobasket = By.xpath("(//button[@type=\"submit\"])[2]");
	By button_wedding = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[1]/a");
	By button_HomeandLiving = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[4]/a/div[1]/div/img");
	By button_Wallart = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[5]/a");
	By button_checkout = By.cssSelector("#atc-overlay-content > div.wt-display-flex-md.wt-flex-direction-column-md.wt-bb-xs.wt-pb-xs-4 > div > a");
	By button_buy = By.xpath("//*[@id=\"multi-shop-cart-list\"]/div[1]/div/div[1]/div/div/div/form/div[2]/div[1]/button");

	
	public buyPageObjects (WebDriver driver) {
		this.driver = driver;
		}
	public void clickjewelleryButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_jewellery).isDisplayed(), "\" jewellery\" button is displayed");
		//Clicking on jewellery button
	driver.findElement (button_jewellery).click(); 
	}
	public void clickshopthisitemButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_shopthisitem).isDisplayed(), "\" shop this item\" button is displayed");
		//Clicking on shop this item button
	driver.findElement (button_shopthisitem).click(); 
	}
	public void clickaddtobasketButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_addtobasket).isDisplayed(), "\" add to basket\" button is displayed");
		//Clicking on add to basket button
	driver.findElement (button_addtobasket).click(); 
	}
	public void clickweddingButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_wedding).isDisplayed(), "\" wedding\" button is displayed");
		//Clicking on wedding button
	driver.findElement (button_wedding).click(); 
	}
	public void clickHomeandLivingButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_HomeandLiving).isDisplayed(), "\" Home and Living\" button is displayed");
		//Clicking on wedding button
	driver.findElement (button_HomeandLiving).click(); 
	}
	public void clickWallartButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_Wallart).isDisplayed(), "\" Wall art\" button is displayed");
		//Clicking on Home and Living button
	driver.findElement (button_Wallart).click(); 
	}
	public void clickcheckoutButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_checkout).isDisplayed(), "\" checkout\" button is displayed");
		//Clicking on Home and Living button
	driver.findElement (button_checkout).click(); 
	}
	public void clickbuyButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_buy).isDisplayed(), "\" checkout\" button is displayed");
		//Clicking on Home and Living button
	driver.findElement (button_buy).click(); 
	}
}
