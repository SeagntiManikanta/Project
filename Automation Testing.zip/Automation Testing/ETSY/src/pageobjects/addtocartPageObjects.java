package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class addtocartPageObjects {
	
	WebDriver driver;
	By button_jewellery = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[2]/a");
	By button_shopthisitem = By.xpath("//*[@id=\"content\"]/div/div[1]/div/div[3]/div[4]/div/div/div/div[2]/a");
	By button_addtobasket = By.cssSelector("#listing-page-cart > div.wt-mb-xs-6.wt-mb-lg-0 > div:nth-child(1) > div.wt-display-flex-xs.wt-flex-direction-column-xs.wt-flex-wrap.wt-flex-direction-row-md.wt-flex-direction-column-lg > div > form > div > button");
	By button_wedding = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[1]/a");
	By button_HomeandLiving = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[4]/a/div[1]/div/img");
	By button_Wallart = By.xpath("//*[@id=\"content\"]/div/div[1]/div[2]/div/ul/li[5]/a");


	
	public addtocartPageObjects (WebDriver driver) {
		this.driver = driver;
		}
	public void clickjewelleryButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_jewellery).isDisplayed(), "\" jewellery\" button is displayed");
		//Clicking on jewellery button
	driver.findElement (button_jewellery).click(); 
	}
	public void clickshopthisitemButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_shopthisitem).isDisplayed(), "\" shop this item\" button is displayed");
		//Clicking on shop this item button
	driver.findElement (button_shopthisitem).click(); 
	}
	public void clickaddtobasketButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_addtobasket).isDisplayed(), "\" add to basket\" button is displayed");
		//Clicking on add to basket button
	driver.findElement (button_addtobasket).click(); 
	}
	public void clickweddingButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_wedding).isDisplayed(), "\" wedding\" button is displayed");
		//Clicking on wedding button
	driver.findElement (button_wedding).click(); 
	}
	public void clickHomeandLivingButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_HomeandLiving).isDisplayed(), "\" Home and Living\" button is displayed");
		//Clicking on wedding button
	driver.findElement (button_HomeandLiving).click(); 
	}
	public void clickWallartButton() {
		//Assertion
		Assert.assertTrue(driver.findElement(button_Wallart).isDisplayed(), "\" Wall art\" button is displayed");
		//Clicking on Home and Living button
	driver.findElement (button_Wallart).click(); 
	}
}
