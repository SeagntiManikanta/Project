package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import pageobjects.SigninPageObjects;

public class signin3 {

	//declaring the variables globally
	static ExtentHtmlReporter spark;	
	static ExtentReports extent;
	static ExtentTest test;
	private static WebDriver driver;
//	static String browser = "Chrome";

@Test
public void sign_inTest() throws Exception{

System.setProperty("webdriver.chrome.driver",  "C:\\Users\\Seganti.Manikanta\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
//object creation for the report
 extent=new ExtentReports();
//setting path for the extent report
 spark=new ExtentHtmlReporter("C:\\HCL training\\program\\core java\\LAB3\\LAB4\\CONSOLE PROJECT\\ETSY\\reportsignin1.html");
extent.attachReporter(spark);
 test=extent.createTest("Verify the Sign in functionality of etsy");
 File datafile = new File( "C:\\HCL training\\program\\core java\\LAB3\\LAB4\\CONSOLE PROJECT\\ETSY\\Etsy_excel\\Excel_data.xlsx");
 FileInputStream fis=new FileInputStream(datafile);
 XSSFWorkbook wb = new XSSFWorkbook(fis);
XSSFSheet sh = wb.getSheet("Sheet1");
 
   //path of data from the excel the sheet
   int rowcount=sh.getPhysicalNumberOfRows();
   String[][] data1=new String[4][2];
   System.out.println(rowcount);
   
   for(int i=1;i<rowcount-1;i++)
   {
   data1[i][0]=sh.getRow(i).getCell(0).getStringCellValue();
   System.out.println(data1[i][0]);
   
   data1[i][1]=sh.getRow(i).getCell(1).getStringCellValue();
   System.out.println(data1[i][1]);
      
   driver = new ChromeDriver();
	//opening the Url
   driver.get("https://www.etsy.com/");
   System.out.println("Title is:"+driver.getTitle());

SigninPageObjects signInPageObj = new SigninPageObjects(driver);
	     //Clicking on SignIn button
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);
        signInPageObj.clickSignInButton();
        //Getting data from excel
        Thread.sleep(5000);
        signInPageObj.setTextEmailaddress(data1[i][0]);
        //Getting data from excel
        signInPageObj.setTextInPassword(data1[i][1]);       
        //Clicking on SignIn button
        signInPageObj.clickSignInButton1();
        
        driver.close(); 
}
	//To erase any previous data on the report and create a new report.
   extent.flush();
}
public static WebDriver getDriver() {
	return driver;
}
public static void setDriver(WebDriver driver) {
	signin3.driver = driver;
}
} 


