package main;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import pageobjects.buyPageObjects;

public class buy4 {

	//declaring the variables globally
	static ExtentHtmlReporter spark;	
	static ExtentReports extent;
	static ExtentTest test;
	private static WebDriver driver;
	static String browser = "Chrome";

@Test
public void buy_Test() throws IOException, InterruptedException{

System.setProperty("webdriver.chrome.driver",  "C:\\Users\\Seganti.Manikanta\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
//object creation for the report
 extent=new ExtentReports();
//setting path for the extent report
 spark=new ExtentHtmlReporter("C:\\HCL training\\program\\core java\\LAB3\\LAB4\\CONSOLE PROJECT\\ETSY\\reportbuy4.html");
extent.attachReporter(spark);
 test=extent.createTest("Verify the buy functionality of etsy");// here we have to give of extent report
      
   driver = new ChromeDriver();
	//opening the Url
   driver.get("https://www.etsy.com/");
   System.out.println("Title is:"+driver.getTitle());

   buyPageObjects buyPageObj = new buyPageObjects(driver);
	     //Clicking on wall art button
		Thread.sleep(5000);
		buyPageObj.clickWallartButton();
		//Clicking on shop this item button
		buyPageObj.clickshopthisitemButton();
		//Clicking on add to basket button
		buyPageObj.clickaddtobasketButton();
		Thread.sleep(5000);
		//Clicking on check out button
		buyPageObj.clickcheckoutButton();
		//Clicking on Buy button
		buyPageObj.clickbuyButton();
		
        driver.close(); 

	//To erase any previous data on the report and create a new report.
   extent.flush();
}
public static WebDriver getDriver() {
	return driver;
}
public static void setDriver(WebDriver driver) {
	buy4.driver = driver;
}
} 

