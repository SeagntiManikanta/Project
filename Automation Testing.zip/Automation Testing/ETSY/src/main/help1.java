package main;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import pageobjects.helpPageObjects;

public class help1 {

	//declaring the variables globally
	static ExtentHtmlReporter spark;	
	static ExtentReports extent;
	static ExtentTest test;
	private static WebDriver driver;
	static String browser = "Chrome";

@Test
public void help_Test() throws IOException, InterruptedException{

System.setProperty("webdriver.chrome.driver",  "C:\\Users\\Seganti.Manikanta\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
//object creation for the report
 extent=new ExtentReports();
//setting path for the extent report
 spark=new ExtentHtmlReporter("C:\\HCL training\\program\\core java\\LAB3\\LAB4\\CONSOLE PROJECT\\ETSY\\reporthelp1.html");
extent.attachReporter(spark);
 test=extent.createTest("Verify the help and contact functionality of etsy");// here we have to give of extent report
      
   driver = new ChromeDriver();
	//opening the Url
   driver.get("https://www.etsy.com/");
   System.out.println("Title is:"+driver.getTitle());

   helpPageObjects helpPageObj = new helpPageObjects(driver);
   
		Thread.sleep(5000);
		//Clicking on help and contact button
		helpPageObj.clickhelpButton();
		Thread.sleep(5000);
		//Clicking on purchasing button
		helpPageObj.clickpurchasingButton();
		
        driver.close(); 

	//To erase any previous data on the report and create a new report.
   extent.flush();
}
public static WebDriver getDriver() {
	return driver;
}
public static void setDriver(WebDriver driver) {
	help1.driver = driver;
}
} 

