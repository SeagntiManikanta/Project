package main;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import pageobjects.addtocartPageObjects;

public class addtocart3 {

	//declaring the variables globally
	static ExtentHtmlReporter spark;	
	static ExtentReports extent;
	static ExtentTest test;
	private static WebDriver driver;
	static String browser = "Chrome";

@Test
public void addtocart_Test() throws IOException, InterruptedException{

System.setProperty("webdriver.chrome.driver",  "C:\\Users\\Seganti.Manikanta\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
//object creation for the report
 extent=new ExtentReports();
//setting path for the extent report
 spark=new ExtentHtmlReporter("C:\\HCL training\\program\\core java\\LAB3\\LAB4\\CONSOLE PROJECT\\ETSY\\reportaddtocart3.html");
extent.attachReporter(spark);
 test=extent.createTest("Verify the add to cart functionality of etsy");// here we have to give of extent report
      
   driver = new ChromeDriver();
	//opening the Url
   driver.get("https://www.etsy.com/");
   System.out.println("Title is:"+driver.getTitle());

   addtocartPageObjects addtocartPageObj = new addtocartPageObjects(driver);
        //Clicking on Home and Living button
		Thread.sleep(5000);
		addtocartPageObj.clickHomeandLivingButton();
		//Clicking on shop this item button
		addtocartPageObj.clickshopthisitemButton();
		//Clicking on add to basket button
		Thread.sleep(5000);
		addtocartPageObj.clickaddtobasketButton();
		
        driver.close(); 

	//To erase any previous data on the report and create a new report.
   extent.flush();
}
public static WebDriver getDriver() {
	return driver;
}
public static void setDriver(WebDriver driver) {
	addtocart3.driver = driver;
}
} 

