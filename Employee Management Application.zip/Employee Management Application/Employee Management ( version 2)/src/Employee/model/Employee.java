package Employee.model;

public class Employee {
    private int id;
    private String name;
    private String experience;
    private String jobrole;
    private String location;

    public Employee(){

    }

    public Employee(String name, String experience, String jobrole, String location) {
        this.name = name;
        this.experience = experience;
        this.jobrole = jobrole;
        this.location = location;
    }

    public Employee(int id, String name, String experience, String jobrole, String location) {
        this.id = id;
        this.name = name;
        this.experience = experience;
        this.jobrole = jobrole;
        this.location = location;
    }
    //getters and setter of constructor
    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getexperience() {
        return experience;
    }

    public void setexperience(String experience) {
        this.experience = experience;
    }

    public String getjobrole() {
        return jobrole;
    }

    public void setSapId(String jobrole) {
        this.jobrole = jobrole;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String Location) {
        this.location = Location;
    }

    @Override
    //built in method of Java which returns itself a string
    public String toString() {
        return "Employee{" +
                "Id=" + id +
                ", name='" + name + '\'' +
                ", experience='" + experience + '\'' +
                ", jobrole='" + jobrole + '\'' +
                ", location=" + location +
                '}';
    }
}