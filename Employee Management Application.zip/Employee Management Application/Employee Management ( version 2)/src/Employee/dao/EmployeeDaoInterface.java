package Employee.dao;

import Employee.model.Employee;

public interface EmployeeDaoInterface {
	// specifies the behavior of a class by providing an abstract type
	/* Interfaces are used in Java to achieve abstraction. (A process of hiding the
	implementation details and showing only functionality to the user)*/
    public boolean insertEmployee(Employee s);
    public boolean delete(int id);
    public boolean update(int id,String update,int ch,Employee s);
    public void showAllEmployee();
    public boolean showEmployeeById(int id);
}