package main;

import java.util.Scanner;

import Employee.dao.EmployeeDao;
import Employee.dao.EmployeeDaoInterface;
import Employee.model.Employee;

public class main {
    private static boolean f;
	private static boolean ff;
	private static boolean ans;
	private static boolean flag;
	public static int Id;
	public static int ID;
	public static int id;
	public static int st;
	public static int choice;
	public static int ch;
	public static String name;
	public static String experience;
	public static String jobrole;
	public static String location;
	public static String sname;
	public static String Experience;
	
	public static void main(String[] args) {
		// Scanner class to give console based inputs
        Scanner sc=new Scanner(System.in);

        //Object creation
        EmployeeDaoInterface dao=new EmployeeDao();
        System.out.println("Welcome to Employee Management application");
        while(true){
            System.out.println("\n1.Add Employee" +
                    "\n2.Show All Employee" +
                    "\n3.Get Employee based on id" +
                    "\n4.Delete Employee"+
                    "\n5.Update Employee" +
                    "\n6.Exit");
            //The main interface of application
            System.out.println("Enter choice");
            ch=sc.nextInt();
            // switch cases for different modules of application
            switch (ch){
                case 1:
                    System.out.println("Add Employee");  // case for adding the Employee module
                    System.out.println("Enter Employee name");
                    name=sc.next();
                    System.out.println("Enter Employee experience");
                    experience=sc.next();
                    System.out.println("Enter jobrole");
                    jobrole=sc.next();
                    System.out.println("Enter Location");
                    location=sc.next();
                    // object creation for Employee
                    Employee st=new Employee(name,experience,jobrole,location);
                    //along with parameters
                    ans=dao.insertEmployee(st);
                    if(ans)
                        System.out.println("Employee details inserted Successfully!!!");
                    else
                        System.out.println("something went wrong, please try again");
                    // break statement takes the flow of control out of the switch statement
                    break;
                case 2:
                	//Case of getting all the Employees from the database
                    System.out.println("Show all Employee ");
                    dao.showAllEmployee();
                    
                    break;
                case 3:
                    //Case of getting particular Employee details
                    System.out.println("Get Employee based on id");
                    //via id
                    System.out.println("enter id");
                    id=sc.nextInt();
                    f = dao.showEmployeeById(id);
                    //Condition if Employee ID is not available in database

                  if(f) {
                      System.out.println("Employee with this id is available in our system");}
                      else 
                    	  {System.out.println("Employee with this id is not available in our system");}
                  //break statement takes the flow of control out of switch statement
                    break;
                case 4:                	
                	 // Case for deletion of the students�������������������� 
                	System.out.println("Delete Employee");
                      System.out.println("Enter� ID to delete");
                	 Id = sc.nextInt();
                	 ff= dao.showEmployeeById(Id);
                	 if (ff) {
                	 ff = dao.delete(Id);
                	 System.out.println("Employee details deleted successfully...");
                	 } else {
                	 System.out.println("Employee with this ID is not available in our system");}
                     // break statement takes the flow of control out of the switch statement
                	 break;
                	
                case 5:
                	//Case for updating the details of Employee
                    System.out.println("Update the Employee details");
                    System.out.println("\n1.Update name\n2.Update location");
                    System.out.println("enter your choice");
                    choice=sc.nextInt();
                    //Choices are again divided for multiple details updating
                    if(choice==1){
                        System.out.println("enter id");
                        ID=sc.nextInt();
                        //Employee name updating
                        System.out.println("Enter new name");
                        sname=sc.next();
                        Employee std=new Employee();
                        std.setName(sname);
                        //Dao refers to data access object
                      flag=  dao.update(ID,sname,choice,std);
                      if(flag)
                          System.out.println(" Employee name updated successfully");
                      else
                          System.out.println("Something went wrong...");
 }
                       else if(choice==2){
                        System.out.println("enter id");
                        ID=sc.nextInt();
                        //Employee age updating
                        System.out.println("Enter correct location");
                        location=sc.next();
                        Employee std=new Employee();
                        std.setLocation(location);
                        //Dao refers to data access object
                      flag=  dao.update(ID,location,choice,std);
                      // flag is used to let program know that certain conditions are met
                      if(flag)
                          System.out.println(" Employee age updated successfully");
                      else
                          System.out.println("Something went wrong...");
 }
                    //break statement takes the flow of control out of switch statement
                    break;
                case 6:
                    System.out.println("Thank You for using Employee management application!!!");
                    //Terminates the current java running machine
                    System.exit(0);
                    //Exiting the application and terminating the program
                default:
                	//to specify the set of statements to execute if
                	// there is no case match 
                    System.out.println("Please enter valid choice....");
            }
        }


    }
}